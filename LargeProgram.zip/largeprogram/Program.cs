﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Threading;
using System.Runtime.Versioning;
using System.Reflection;
using System.Text;
using System.Numerics;
using System.Threading.Tasks;

using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace largeprogram
{
    public static class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Application started\n");
            Console.WriteLine("Need to create Large file More than 1GB? \nPress y/n...");
            var cf = Console.ReadLine();

            var fileLocation = "";
            if (cf.ToLower() == "y")
            {
                fileLocation = CreateLargeFileMaxTenGB(null, 1);
                Console.WriteLine("File successfully created.\nFile name - " + new FileInfo(fileLocation).FullName +"\nFile size - " + GetFileSize(fileLocation));
            }
            else
            {
                Console.WriteLine("Please enter input file location");
                fileLocation = Console.ReadLine();
            }
            Console.WriteLine("\n\nExtracting even number from " + fileLocation);

            var outputFile = WriteEvenNumberInFile(fileLocation);

            Console.WriteLine("Successfully even numbers extracted \nFrom - " + new FileInfo(fileLocation).FullName + "\nTo - " + new FileInfo(outputFile).FullName + "\nFile size - " + GetFileSize(outputFile));

            Console.WriteLine("\n\nNeed to upload in cloud storage? \nPress y/n...");
            var upload = Console.ReadLine();
            if (upload == "y")
            {
                var uploadedocation = FileUploadToCloudAsync(outputFile);
                Console.WriteLine("File can download from following location \n" + uploadedocation);
            }

            Console.WriteLine("Application successfully finished");
            Console.ReadLine();
        }

        public static string FileUploadToCloudAsync(string filePath)
        {
            try
            {
                var storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=azurebloblargefile;AccountKey=SxO96y990Q9CzSu3I+kZVhDglxPD8jA4Nw47vIQSjDWE0Wb/qZrYU4XzLfTDmmKec18ASIE27UqnoiD3M+/SrQ==;EndpointSuffix=core.windows.net");
                var myClient = storageAccount.CreateCloudBlobClient();

                var container = myClient.GetContainerReference("largefilestorage1");

                container.CreateIfNotExistsAsync().Wait();

                //lines modified
                var blockBlob = container.GetBlockBlobReference(new FileInfo(filePath).Name);
                Console.WriteLine("File start uploading.");

                var x = blockBlob.UploadFromFileAsync(new FileInfo(filePath).Name);
                x.Wait();
                Console.WriteLine("File uploaded.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return "https://azurebloblargefile.blob.core.windows.net/largefilestorage1/" + new FileInfo(filePath).Name;
        }


        public static string WriteEvenNumberInFile(string filePath)
        {
            if (!File.Exists(filePath)) throw new FileNotFoundException(filePath);

            var desFilePath = Guid.NewGuid().ToString() + ".txt";

            using (FileStream fs = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (BufferedStream bs = new BufferedStream(fs))
            using (StreamReader sr = new StreamReader(bs))
            {
                using (StreamWriter outfile = new StreamWriter(desFilePath))
                {
                    try
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if ((int.Parse(line) & 1) == 0)
                            {
                                outfile.WriteLine(line);
                            }
                        }
                    }
                    catch (System.Exception)
                    {
                        throw;
                    }
                }
            }

            return desFilePath;
        }

        public static string RandomNumberGenerator()
        {
            string s = "";
            Random r = new Random();
            for (int i = 0; i < Int16.MaxValue; i++)
            {
                s += r.Next() + "\n";
            }
            return s;
        }

        public static string CreateLargeFileMaxTenGB(string path = null, int? size = null)
        {
            if (path == null)
            {
                path = Guid.NewGuid().ToString() + ".txt";
            }
            else
            {
                if (new FileInfo(path).Extension.ToLower() != "txt") throw new FileLoadException("File not acceptable. only .txt file acceptable");
            }

            var s = RandomNumberGenerator();

            if (size == null) size = 2;
            else
            {
                if (size > 10) size = 10;

                size = (Int16.MaxValue / 10) * size;

            }
            using (StreamWriter outfile = new StreamWriter(path))
            {
                for (int i = 0; i < size; i++)// 
                {
                    outfile.Write(s);
                }
            }

            return path;
        }

        private static string GetFileSize(string filename)
        {
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            double len = new FileInfo(filename).Length;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }

            // Adjust the format string to your preferences. For example "{0:0.#}{1}" would
            // show a single decimal place, and no space.
            string result = String.Format("{0:0.##} {1}", len, sizes[order]);

            return result;
        }
    }
}
