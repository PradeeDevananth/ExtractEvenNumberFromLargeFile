﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using largeprogram;
using System;
using System.Collections.Generic;
using System.Text;

namespace largeprogram.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        
        [TestMethod()]
        public void WriteEvenNumberInFileTestFailCase()
        {
            //Arrange
            var file = "filenotfound.txt";
            try
            {
                //Act
                largeprogram.Program.WriteEvenNumberInFile(file);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is System.IO.FileNotFoundException);
                return;
            }

            Assert.Fail();
        }

        [TestMethod]
        public void WriteEvenNumberInFileTestPassCase()
        {
            //Arrange and Moq
            var file = largeprogram.Program.CreateLargeFileMaxTenGB();

            var output = "";
            try
            {
                //Act
                output = largeprogram.Program.WriteEvenNumberInFile(file);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.Fail(ex.Message);
                return;
            }

            //Assert
            Assert.IsTrue(System.IO.File.Exists(output));
        }

        [TestMethod()]
        public void RandomNumberGeneratorTest()
        {
            //Arrange and Act
            try
            {
                var s = largeprogram.Program.RandomNumberGenerator();

                //Assert 
                Assert.IsTrue(!string.IsNullOrEmpty(s));
                return;
            }
            catch (Exception ex)
            {
                //Assert
                Assert.Fail(ex.Message);
                return;
            }
        }

        [TestMethod()]
        public void CreateLargeFileMaxTenGBTestFileFailCase()
        {
            try
            {
                //Arrange and Act
                largeprogram.Program.CreateLargeFileMaxTenGB("testfile.ntt");

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is System.IO.FileLoadException);
                return;
            }

            //Assert
            Assert.Fail();

        }

        [TestMethod()]
        public void CreateLargeFileMaxTenGBTestFilePassCase()
        {
            try
            {
                //Aggange and Act
                var file = largeprogram.Program.CreateLargeFileMaxTenGB("testfile.txt");

                //Assert
                Assert.IsTrue(System.IO.File.Exists(file));
                return;
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is System.IO.FileLoadException);
                return;
            }
        }
    }
}